REGISTRY = {}

from .mlp import MLPEstimator
REGISTRY["mlp"] = MLPEstimator